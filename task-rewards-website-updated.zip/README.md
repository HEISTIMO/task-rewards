# TaskRewards — starter website

This is a front-end prototype for the task/rewards flow discussed.

## Included
- Bank-details entry screen (no sign-in UI)
- Premium responsive dashboard
- Facebook and TikTok task links
- ₦600 task reward display
- Locked final-task section
- WhatsApp share buttons
- ₦3,000 withdrawal threshold
- Wallet and withdrawal-history UI
- Live themes
- Mobile bottom navigation
- Local browser persistence for prototype testing

## Important
This version is intentionally a prototype. It stores demo state in the browser's localStorage. It does NOT securely store bank details, process real payments, or automatically verify Facebook/TikTok/WhatsApp actions.

For a production launch, connect a secure backend and implement server-side authorization, validation, fraud controls, privacy protections, and a legitimate task-verification/payment workflow. Firebase's official documentation recommends Firebase Authentication plus Cloud Firestore Security Rules for protecting web/mobile Firestore data, and warns against open production rules.

Do not collect PINs, OTPs, card numbers, or other banking credentials.

## Run
Open `index.html` in a browser, or deploy the folder to your preferred static host.

## Next production step
Replace localStorage persistence with a secure backend and server-side verification/payment workflow before collecting real financial information.
